import { DataService } from './../services/data.service';
import { Component, OnInit } from '@angular/core';



@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit {

    pets: any[];
    public searchTerm = '';
    constructor(private petsInfo: DataService) { }

ngOnInit() {
  this.pets = this.petsInfo.getDetails().info;
  this.setFilteredItems();
}

setFilteredItems() {
  this.pets = this.petsInfo.filter(this.searchTerm);
  }

}
