import { DataService } from './../../services/data.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-birds',
  templateUrl: './birds.component.html',
  styleUrls: ['./birds.component.scss'],
})
export class BirdsComponent implements OnInit {

  constructor( private router: ActivatedRoute, private user: DataService) { }
info: any [];

  ngOnInit() {
this.info = this.user.getDetails().info;
console.log ( this.info);
  }

}
