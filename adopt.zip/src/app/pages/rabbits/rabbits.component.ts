import { Component, OnInit } from '@angular/core';
import { DataService } from './../../services/data.service';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-rabbits',
  templateUrl: './rabbits.component.html',
  styleUrls: ['./rabbits.component.scss'],
})
export class RabbitsComponent implements OnInit {

  constructor( private router: ActivatedRoute, private user: DataService) { }
  info: any [];

    ngOnInit() {
  this.info = this.user.getDetails2().info;
  console.log ( this.info);
    }

  }
