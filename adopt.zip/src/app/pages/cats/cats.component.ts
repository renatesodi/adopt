import { InfoData } from './../../services/cats';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataService } from './../../services/data.service';

@Component({
  selector: 'app-cats',
  templateUrl: './cats.component.html',
  styleUrls: ['./cats.component.scss'],
})
export class CatsComponent implements OnInit {

  constructor( private router: ActivatedRoute, private user: DataService) { }
  data: any [];

    ngOnInit() {
  this.data = this.user.getDetails1().data;
  console.log (this.user.getDetails1());
    }

  }

