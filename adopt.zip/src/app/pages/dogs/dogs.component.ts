import { Component, OnInit, NgModule } from '@angular/core';
import { DataService } from './../../services/data.service';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-dogs',
  templateUrl: './dogs.component.html',
  styleUrls: ['./dogs.component.scss'],
})

export class DogsComponent implements OnInit {

  constructor( private router: ActivatedRoute, private user: DataService, ) { }
  info: any [];

    ngOnInit() {
  this.info = this.user.getDetails3().info;
  console.log ( this.info);
    }

  }
