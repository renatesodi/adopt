import { NgModule } from '@angular/core';
import { DataService } from './services/data.service';
import { InfoData } from './services/cats';
import { PersonsInfo } from './services/rabbits';
import { UserInformation } from './services/birds';
import { User } from './services/dogs';

import { RabbitsComponent } from './pages/rabbits/rabbits.component';
import { BirdsComponent } from './pages/birds/birds.component';
import { CatsComponent } from './pages/cats/cats.component';
import { DogsComponent } from './pages/dogs/dogs.component';
import { AboutComponent } from './pages/about/about.component';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';
import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { Camera } from '@ionic-native/camera/ngx';

import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [AppComponent,
     AboutComponent, DogsComponent, CatsComponent, BirdsComponent,
     RabbitsComponent ],
  entryComponents: [],
  imports: [
    BrowserModule,
    FormsModule,
    IonicModule.forRoot(),
    AppRoutingModule,
    ReactiveFormsModule
  ],
  providers: [
    StatusBar, Camera,
    SplashScreen,
    User, UserInformation, PersonsInfo, InfoData,
    DataService,
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}

