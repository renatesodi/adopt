export class UserInformation {
    info: any[] = [
        { id: 1, name: 'Sparrow' , img: 'https://www.petmd.com/sites/default/files/7-541143430.gif' , dsc: '', },
        { id: 1, name: 'Coco' , img: 'https://s7d2.scene7.com/is/image/PetSmart/AR1501_TOPIC_IMAGE-NewPetBirdChecklistA-20160818?$AR1501$' , dsc: '', },
        { id: 1, name: 'Pikachu' , img: 'https://s7d2.scene7.com/is/image/PetSmart/AR1501_TOPIC_IMAGE-NewPetBirdChecklist-20160818?$AR1501$' , dsc: '',},
        { id: 1, name: 'Norris' , img: 'https://s7d2.scene7.com/is/image/PetSmart/ARHERO-WhatShouldIFeedMyBird-20160818?$AR0301$' , dsc: '',},
        { id: 1, name: 'Zazu, Sunny' , img: 'https://s7d2.scene7.com/is/image/PetSmart/ARHERO-CaringForYourBird-20160818?$AR0301$'},

    ];
  }
