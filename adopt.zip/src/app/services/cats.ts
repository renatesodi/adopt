export class InfoData {
    data: any[] = [
        { id: 1, name: 'Allergia' , img: 'https://thenypost.files.wordpress.com/2019/12/cat.jpg?quality=80&strip=all&w=618&h=410&crop=1'},
        { id: 1, name: 'Orlando' , img: 'https://www.cats.org.uk/media/2197/financial-assistance.jpg?width=1600'},
        { id: 1, name: 'Britania' , img: 'https://cdn.britannica.com/48/7148-004-6C88ACBC/Persian-cream-bicolour.jpg'},
        { id: 1, name: 'Persian' , img: 'https://i.pinimg.com/originals/a1/d8/e7/a1d8e7d9f7fd93e2399e482dacaec46c.jpg'},
        { id: 1, name: 'Peruna' , img: 'https://www.purina.com/sites/g/files/auxxlc196/files/styles/facebook_share/public/how-to-handle-a-territorial-cat-500x300.jpg?itok=Qk13uzz9'},
    ];  }
