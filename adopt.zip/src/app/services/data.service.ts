import { InfoData } from './cats';
import { PersonsInfo } from './rabbits';
import { User } from './dogs';
import { UserInformation } from './birds';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(public birds: UserInformation, public cats: InfoData, public rabbits: PersonsInfo, public dogs: User) { }

  filter(searchTerm) {
    return this.birds.info.filter((item) => {
      return item.name.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
    });
  }

  getDetails() {
    return this.birds;
  }
  getDetails1() {
    return this.cats;

  }
  getDetails2() {
    return this.rabbits;
  }
  getDetails3() {
    return this.dogs;
  }
}

