export class User {
    info: any[] = [
        { id: 1, name: 'Achie' , img: 'https://i.dailymail.co.uk/1s/2019/11/23/09/21370544-7717313-image-a-1_1574501083030.jpg'},
        { id: 1, name: 'Charlie' , img: 'https://www.kimballstock.com/pix/DOG/18/DOG_18_KH0004_01_P.JPG'},
        { id: 1, name: 'Max' , img: 'https://cdn2-www.dogtime.com/assets/uploads/2011/01/file_23214_goldador-460x290.jpg'},
        { id: 1, name: 'Molly' , img: 'https://royaldogsandpuppies.files.wordpress.com/2018/12/rottweiler-2160308__340.jpg?w=640'},
        { id: 1, name: 'Bella' , img: 'https://image.shutterstock.com/image-photo/jack-russell-terrier-standing-on-260nw-257600260.jpg'},
    ];  }
