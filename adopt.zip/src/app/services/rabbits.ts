export class PersonsInfo {
    info: any[] = [
        { id: 1, name: 'Nibles' , img: 'https://images.unsplash.com/photo-1518796745738-41048802f99a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80'},
        { id: 1, name: 'Dapper' , img: 'https://api.time.com/wp-content/uploads/2019/03/us-movie-rabbits-meaning.jpg?w=600&quality=85'},
        { id: 1, name: 'Shimmer' , img: 'https://www.media4pillar.com/wp-content/uploads/2017/09/rabbit.jpg'},
        { id: 1, name: 'sparkle ,Hazey' , img: 'https://www.telegraph.co.uk/content/dam/news/2019/04/17/TELEMMGLPICT000194091375_trans_NvBQzQNjv4Bq1TJOa7BZ2Re4vzncv8bVrxi4GB-4tR5Il4FFM2mWZkk.jpeg?imwidth=450'},
        { id: 1, name: 'Trixy' , img: 'https://www.oxbowanimalhealth.com/uploads/files/Feb_2019_blog_rabbit_noises.png'},
    ];  }
