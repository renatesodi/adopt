
import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { CatsComponent } from './pages/cats/cats.component';
import { BirdsComponent } from './pages/birds/birds.component';
import { RabbitsComponent } from './pages/rabbits/rabbits.component';
import { DogsComponent } from './pages/dogs/dogs.component';
import { AboutComponent } from './pages/about/about.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  { path: 'home', loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
},
  {
    path: 'about', component: AboutComponent
  },

  {
    path: 'dogs', component: DogsComponent

  },

  {
    path: 'cats', component: CatsComponent

  },
  {
    path: 'rabbits', component: RabbitsComponent

  },
  {
    path: 'birds', component: BirdsComponent

  },
    {
      path: 'add',
      loadChildren: () => import('./add/add.module').then( m => m.AddPageModule)
    },
    {
      path: 'contact',
      loadChildren: () => import('./contact/contact.module').then( m => m.ContactPageModule)
    },
  {
    path: 'folder',
    loadChildren: () => import('./folder/folder.module').then( m => m.FolderPageModule)
  },
  {
    path: 'adding',
    loadChildren: () => import('./adding/adding.module').then( m => m.AddingPageModule)
  },

];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
