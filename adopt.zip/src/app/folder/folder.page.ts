import { FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Component, OnInit, NgModule } from '@angular/core';
import { Container } from '@angular/compiler/src/i18n/i18n_ast';

@Component({
  selector: 'app-folder',
  templateUrl: './folder.page.html',
  styleUrls: ['./folder.page.scss'],
})
export class FolderPage implements OnInit {
  constructor() { }

  ngOnInit() {
  }}
